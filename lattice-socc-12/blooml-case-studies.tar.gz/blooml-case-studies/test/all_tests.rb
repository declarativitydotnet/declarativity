require './test_common'
require 'test/tc_kvs'
require 'test/tc_monotone_cart'
